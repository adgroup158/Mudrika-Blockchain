# Mudrikā Blockchain Whitepaper

## Introduction
Mudrikā is an innovative, scalable blockchain...
# MDK98 Tokenomics

- Total Supply: 1 Billion
- Initial Distribution: 40% ICO, 30% Ecosystem, ...
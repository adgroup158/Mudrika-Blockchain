# Mudrikā Blockchain

Mudrikā is a decentralized public blockchain supporting the MDK98 token standard.

## Features
- EVM Compatibility
- MDK98 Token Standard
- Proof-of-Work or Configurable Consensus
- Multi-node and Peer-to-Peer Communication
- Web3 and REST APIs

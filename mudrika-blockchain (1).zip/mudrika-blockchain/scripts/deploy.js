// Hardhat deployment script
const hre = require("hardhat");

async function main() {
  const MDK98 = await hre.ethers.getContractFactory("MDK98Token");
  const token = await MDK98.deploy();
  await token.deployed();
  console.log("MDK98 deployed to:", token.address);
}

main();